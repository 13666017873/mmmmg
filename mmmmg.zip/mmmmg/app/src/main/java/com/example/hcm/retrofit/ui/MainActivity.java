package com.example.hcm.retrofit.ui;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.example.hcm.retrofit.R;
import com.example.hcm.retrofit.api.HttpManager;
import com.example.hcm.retrofit.entity.InfoSayCardList;
import com.example.hcm.retrofit.tools_kit.ToolHttpService;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import rx.Observable;
import rx.Subscriber;
import rx.schedulers.Schedulers;

public class MainActivity extends AppCompatActivity {

    private final ProgressDialog pd = new ProgressDialog(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView textView = findViewById(R.id.text);

        okhttp3.OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(5, TimeUnit.SECONDS);

        Retrofit retrofit = new Retrofit.Builder()
                .client(builder.build())
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .baseUrl(HttpManager.BASE_URL)
                .build();

        ToolHttpService apiService = retrofit.create(ToolHttpService.class);
        Observable<InfoSayCardList> observable = apiService.getAllVedioBy("513115308920143872");
        observable.subscribeOn(Schedulers.io()).unsubscribeOn(Schedulers.io())
                .subscribe(
                        new Subscriber<InfoSayCardList>() {
                            @Override
                            public void onCompleted() {
                                if (pd.isShowing()) pd.dismiss();
                            }

                            @Override
                            public void onError(Throwable e) {
                                if (pd.isShowing()) pd.dismiss();
                            }

                            @Override
                            public void onNext(InfoSayCardList infoSayCardList) {
                                textView.setText(infoSayCardList.getAuthorid());
                            }

                            @Override
                            public void onStart() {
                                super.onStart();
                                pd.show();
                            }
                        }

                );
    }
}
