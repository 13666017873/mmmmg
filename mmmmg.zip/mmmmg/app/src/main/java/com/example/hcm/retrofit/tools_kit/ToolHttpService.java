package com.example.hcm.retrofit.tools_kit;

import com.example.hcm.retrofit.entity.InfoSayCardList;
import com.example.hcm.retrofit.entity.RetrofitEntity;

import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import rx.Observable;

public interface ToolHttpService {

    @Headers({
            "Accept-Language: zh-CN,zh;q=0.8",
            "User-Agent: Mozilla\\/5.0 (Linux; U; Android 5.1; zh-cn; OPPO A59m Build\\/LMY47I) AppleWebKit\\/537.36 (KHTML, like Gecko) Version\\/4.0 Mobile Safari\\/537.36",
            "deviceid: b83e36331894d9ac",
            "subscriberid: 512346342937329664",
            "timestamp: 1542427092497",
            "token: 5709aba4f2414a2fb90eedc3dd3e9b2c",
            "softversion: 1.0.0",
            "format: json",
            "clientId: 2",
            "sign: 38fc29672e68fc86758900537aed86cc"
    })

    @POST("piazza/getSaycardsaycardid")
    Observable<InfoSayCardList> getAllVedioBy(@Body String sayCardId);
}
