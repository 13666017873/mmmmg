package com.example.hcm.retrofit.api;

public class HttpManager {

    public static final String BASE_URL = "http://47.92.144.168:8080/change/";
}
