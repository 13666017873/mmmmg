package com.example.hcm.retrofit.entity;

public class InfoSayCardList {

    /**
     * authorid : 493415389393321966
     * backgroundpic : card_happy_3.png
     * content : 哎呦喂111
     * createtime : 2018-10-15 09:17:13
     * followcount : 0
     * islike : 0
     * likecount : 0
     * saycardid : 501322647762632704
     * title : 脑瓜疼脑瓜疼
     */

    private String authorid;
    private String backgroundpic;
    private String content;
    private String createtime;
    private int followcount;
    private int islike;
    private int likecount;
    private String saycardid;
    private String title;

    public String getAuthorid() {
        return authorid;
    }

    public void setAuthorid(String authorid) {
        this.authorid = authorid;
    }

    public String getBackgroundpic() {
        return backgroundpic;
    }

    public void setBackgroundpic(String backgroundpic) {
        this.backgroundpic = backgroundpic;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public int getFollowcount() {
        return followcount;
    }

    public void setFollowcount(int followcount) {
        this.followcount = followcount;
    }

    public int getIslike() {
        return islike;
    }

    public void setIslike(int islike) {
        this.islike = islike;
    }

    public int getLikecount() {
        return likecount;
    }

    public void setLikecount(int likecount) {
        this.likecount = likecount;
    }

    public String getSaycardid() {
        return saycardid;
    }

    public void setSaycardid(String saycardid) {
        this.saycardid = saycardid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String transTime(){
        return getCreatetime().replaceAll("-", ".").substring(0, 10);
    }
}
